const sqlite3 = require('sqlite3').verbose();

// Initialize database connection (don't close it here!)
const db = new sqlite3.Database('./database.db', sqlite3.OPEN_READWRITE | sqlite3.OPEN_CREATE, (err) => {
  if (err) {
    console.error('Database connection error:', err);
    process.exit(1);
  }
  console.log('Connected to SQLite database');
});

async function initializeDB() {
  try {
    // Enable foreign key constraints
    await dbRun('PRAGMA foreign_keys = ON');

    // Create tables if they don't exist
    await dbRun(`CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      balance INTEGER DEFAULT 1000 CHECK(balance >= 0)
    )`);

    await dbRun(`CREATE TABLE IF NOT EXISTS transactions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sender_id INTEGER NOT NULL,
      receiver_id INTEGER NOT NULL,
      amount INTEGER NOT NULL CHECK(amount > 0),
      timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(sender_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY(receiver_id) REFERENCES users(id) ON DELETE CASCADE
    )`);

    // Insert initial data only if users table is empty
    const userCount = await dbGet('SELECT COUNT(*) as count FROM users');
    if (userCount.count === 0) {
      await dbRun(
        `INSERT INTO users (username, balance) VALUES 
         ('Alice', 1000), ('Bob', 1000), ('Clara', 1000), ('Dawn', 1000)`
      );
      console.log('Inserted 4 sample users');
    }

    // Verify initialization
    const users = await dbAll('SELECT * FROM users');
    console.log('Current users:', users);

  } catch (err) {
    console.error('Initialization error:', err);
  }
}

// Helper functions
function dbRun(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function(err) {
      err ? reject(err) : resolve(this);
    });
  });
}

function dbGet(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => {
      err ? reject(err) : resolve(row);
    });
  });
}

function dbAll(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => {
      err ? reject(err) : resolve(rows);
    });
  });
}

// Initialize but don't close the connection!
initializeDB();

module.exports = db;  // Export the db connection for other files