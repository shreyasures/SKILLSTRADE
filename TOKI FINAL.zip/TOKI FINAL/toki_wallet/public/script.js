// public/script.js

async function fetchBalances() {
  const res = await fetch('/balances');
  const users = await res.json();

  const board = document.getElementById('balanceBoard');
  board.innerHTML = '';

  users.forEach(user => {
    const card = document.createElement('div');
    card.className = 'balance-card';
    card.innerHTML = `<div>${user.username}</div><div>💰 ${user.balance} Toki</div>`;
    board.appendChild(card);
  });

  const senderSelect = document.getElementById('sender');
  const receiverSelect = document.getElementById('receiver');
  senderSelect.innerHTML = '';
  receiverSelect.innerHTML = '';
  users.forEach(user => {
    const opt1 = new Option(user.username, user.id);
    const opt2 = new Option(user.username, user.id);
    senderSelect.appendChild(opt1);
    receiverSelect.appendChild(opt2);
  });
}

async function fetchTransactions() {
  const res = await fetch('/transactions');
  const data = await res.json();
  const container = document.getElementById('transactions');
  container.innerHTML = '';

  data.transactions.forEach(txn => {
    const p = document.createElement('p');
    p.innerHTML = `💳 <strong>${txn.sender}</strong> ➡️ <strong>${txn.receiver}</strong> | 💰 <strong>${txn.amount}</strong> Toki<br/><small>🕒 ${new Date(txn.timestamp).toLocaleString()}</small>`;
    container.appendChild(p);
  });
}

async function sendToki() {
  const sender = document.getElementById('sender').value;
  const receiver = document.getElementById('receiver').value;
  const amount = document.getElementById('amount').value;

  if (sender === receiver) {
    alert("Sender and receiver can't be the same!");
    return;
  }

  const res = await fetch('/transaction', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ sender, receiver, amount })
  });

  const data = await res.json();
  alert(data.message);
  fetchBalances();
  fetchTransactions();
}

window.onload = () => {
  fetchBalances();
  fetchTransactions();
};
