// server.js
const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const db = new sqlite3.Database('./databse.db');

app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// Create users and transactions table
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT,
    balance INTEGER
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sender_id INTEGER,
    receiver_id INTEGER,
    amount INTEGER,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  // Initialize 5 users if not already added
  db.all("SELECT COUNT(*) as count FROM users", (err, rows) => {
    if (rows[0].count === 0) {
      const users = ['Alice', 'Bob', 'Charlie', 'Diana', 'Eve'];
      const stmt = db.prepare("INSERT INTO users (username, balance) VALUES (?, ?)");
      users.forEach(user => stmt.run(user, 1000));
      stmt.finalize();
    }
  });
});

// Endpoint to send Toki
app.post('/transaction', (req, res) => {
  const { sender, receiver, amount } = req.body;

  if (sender === receiver) {
    return res.json({ success: false, message: "Sender and receiver cannot be the same" });
  }

  db.get("SELECT balance FROM users WHERE id = ?", [sender], (err, row) => {
    if (!row || row.balance < amount) {
      return res.json({ success: false, message: "Insufficient funds" });
    }

    db.serialize(() => {
      db.run("UPDATE users SET balance = balance - ? WHERE id = ?", [amount, sender]);
      db.run("UPDATE users SET balance = balance + ? WHERE id = ?", [amount, receiver]);
      db.run("INSERT INTO transactions (sender_id, receiver_id, amount) VALUES (?, ?, ?)", [sender, receiver, amount]);
      res.json({ success: true, message: "Transaction successful" });
    });
  });
});

// Endpoint to get transactions
app.get('/transactions', (req, res) => {
  db.all(`SELECT t.*, s.username AS sender, r.username AS receiver
          FROM transactions t
          JOIN users s ON t.sender_id = s.id
          JOIN users r ON t.receiver_id = r.id
          ORDER BY t.timestamp DESC`, [], (err, rows) => {
    res.json({ transactions: rows });
  });
});

// Endpoint to get current balances
app.get('/balances', (req, res) => {
  db.all("SELECT id, username, balance FROM users", [], (err, rows) => {
    res.json(rows);
  });
});

app.listen(3000, () => {
  console.log('✅ Toki Wallet running at http://localhost:3000');
});
